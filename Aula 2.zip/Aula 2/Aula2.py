print("Voyage voyage")

#tipo -> str = string (texto)
#int = inteiro (números)
#tipo -> bool = boolean (verdadeiro ou falso) 

#variáveis = valores
nome_usuario = "João Carlos Pires" 
idade_usuario = 19
altura_usuario= 1.86
maior_de_idade = True 


print("Hey! Your name is" , nome_usuario, "Your age is" , idade_usuario, "its height is" , altura_usuario , "You are of legal age?" , maior_de_idade)

