print("Morning Dear")
print("i hope you have a beautiful day, just like your smile")
print(" and i'm happy that you're able to do what you want so much, kiss bye")
print("with care: jcforevermine")

meu_nome = "João Carlos Pires"
minha_idade = "19"
minha_altura = "1.86"
